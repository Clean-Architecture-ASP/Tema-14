namespace CleanArchitecture.Domain.Vehiculos;

public record Modelo(string Value);